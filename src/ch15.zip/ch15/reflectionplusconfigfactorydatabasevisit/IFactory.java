package ch15.reflectionplusconfigfactorydatabasevisit;


public interface IFactory
{
	public IUser createUser(); 
	public IDepatment createDepartment();
}


