package ch15.reflectionplusfactorydatabasevisit;


public interface IFactory
{
	public IUser createUser(); 
	public IDepatment createDepartment();
}


